<?php include 'header.php'; ?>

<div class="container success-container">
    <h1 class="success-title">Cảm ơn bạn đã mua hàng!</h1>
    <p class="lead">Đơn hàng của bạn đã được đặt thành công. Bạn sẽ nhận được email xác nhận sớm.</p>
    <a href="index" class="btn btn-continue mt-3">Tiếp tục mua hàng</a>
</div>

<?php include 'footer.php'; ?>
